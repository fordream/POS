package model;

public class Mypassword {
	private String password;

	
	public Mypassword() {
		super();
		this.password = "0000";
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	} 

	

}
