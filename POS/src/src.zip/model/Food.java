package model;

public class Food extends Menu {

	public Food(String name, int price) {
		super(name, price);
	}

	
}
