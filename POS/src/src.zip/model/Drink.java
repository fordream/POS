package model;

public class Drink extends Menu {

	public Drink(String name, int price) {
		super(name, price);
	}

	
}
