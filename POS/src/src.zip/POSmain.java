import java.net.InetAddress;
import java.net.NetworkInterface;

import GUI.LoginPage;


public class POSmain {

	public static void main(String[] args)
	{
		LoginPage loginPage = new LoginPage();
	}
}
